package Ebox112;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException {
		Scanner scan = new Scanner(System.in);
		FileWriter fileWriter = null;
		try {
			fileWriter = new FileWriter("C:\\Users\\768712\\Desktop\\player.csv");
			System.out.println("Enter the name of the player");
			String fileName = scan.nextLine();
			System.out.println("Enter the team name");
			String teamName = scan.nextLine();
			System.out.println("Enter the number of matches played");
			String noOfMatches = scan.nextLine();
			String finalString = fileName + "," + teamName + "," + noOfMatches;
			fileWriter.write(finalString);
		} catch (IOException e) {
			System.out.println(e);
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			fileWriter.close();
			scan.close();
		}
	}

}
