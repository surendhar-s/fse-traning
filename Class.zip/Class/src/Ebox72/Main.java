package Ebox72;

import java.util.Scanner;

public class Main {

	void display() {

	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Product product[] = new Product[2];
		for (int i = 0; i < 2; i++) {
			System.out.println("Enter the product id");
			Long id = new Long(Long.parseLong(scan.nextLine()));
			System.out.println("Enter the product name");
			String productName = scan.nextLine();
			System.out.println("Enter the supplier name");
			String supplierName = scan.nextLine();
			product[i] = new Product();
			product[i].setId(id);
			product[i].setProductName(productName);
			product[i].setsupplierName(supplierName);
		}
		if (product[0].equals(product[1]))
			System.out.println("The two products are the same");
		else
			System.out.println("The two products are different");
		scan.close();
	}

}
