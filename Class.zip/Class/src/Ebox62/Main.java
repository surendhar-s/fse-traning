package Ebox62;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Menu\n1.Player details of the delivery\n2.Run details of the delivery");
		int choice = Integer.parseInt(scan.nextLine());
		Delivery delivery = new Delivery();
		switch (choice) {
		case 1:
			System.out.println("Enter the bowler name");
			String bowler = scan.nextLine();
			System.out.println("Enter the batsman name");
			String batsman = scan.nextLine();
			delivery.displayDeliveryDetails(bowler, batsman);
			break;
		case 2:
			System.out.println("Enter the numner of runs");
			Long runs = new Long(scan.nextLong());
			delivery.displayDeliveryDetails(runs);
			break;
		default:
			break;
		}
		scan.close();
	}

}
