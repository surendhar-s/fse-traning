package Ebox62;

public class Delivery {
	void displayDeliveryDetails(String bowler, String batsman) {
		String bowlerNameSplitter[]=bowler.split(" ");
		String batsmanNameSplitter[]=batsman.split(" ");
		System.out.println("Bowler : "+bowlerNameSplitter[bowlerNameSplitter.length-1]);
		System.out.println("Batsman : "+batsmanNameSplitter[batsmanNameSplitter.length-1]);
		}

	void displayDeliveryDetails(Long runs) {
		int key = runs.intValue();
		switch (key) {
		case 4:
			System.out.println("Number of runs scored in the delivery : " + key);
			System.out.println("It is a boundary.");
			break;
		case 6:
			System.out.println("Number of runs scored in the delivery : " + key);
			System.out.println("It is a Sixer.");
			break;
		default:
			System.out.println("Number of runs scored in the delivery : " + key);
			break;
		}
	}
}
