package Ebox41;

import java.util.Scanner;

public class Ebox35 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int n=scan.nextInt(),sum=0;
		int arr[]=new int[5];
		for(int i=0;i<n;i++) {
			arr[i]=scan.nextInt();
			sum+=arr[i];
		}
		System.out.println(sum);
		scan.close();
	}
}
