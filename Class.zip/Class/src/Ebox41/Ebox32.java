package Ebox41;

import java.util.Scanner;

public class Ebox32 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the content of the document");
		String givenString=scan.nextLine();
		System.out.println("Enter the old name of the company");
		String replaceString=scan.nextLine();
		System.out.println("Enter the new name of the company");
		String toBeRepalce=scan.next();
		String resultString=givenString.replaceAll(replaceString, toBeRepalce);
		System.out.println(resultString);
		scan.close();
	}

}
