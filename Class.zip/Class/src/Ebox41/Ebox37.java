package Ebox41;

import java.util.Scanner;

public class Ebox37 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int n=scan.nextInt(),sum=0;
		int arr[]=new int[5];
		for(int i=0;i<n;i++) {
			arr[i]=scan.nextInt();
		}
		for(int a:arr)
			sum+=a;
		System.out.println(sum);
		scan.close();
	}

}
