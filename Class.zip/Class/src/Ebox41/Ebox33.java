package Ebox41;

import java.util.Scanner;

public class Ebox33 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		String day[]={"Sun","Mon","Tue","Wed","Thu","Fri","Sat"};
		System.out.println("Enter the day number");
		int n=scan.nextInt();
		System.out.println("Day of the week is "+day[n-1]);
		scan.close();
	}
}
