package Ebox41;

import java.util.Scanner;

public class Ebox41 {
	public static float calculateProfit(int toysPurchased, int pricePerDozen, int sellingPrice) {
		float costPrice = pricePerDozen / (float) 12;
		float profit = sellingPrice - costPrice;
		float profitPercentage = (profit / costPrice) * 100;
		return profitPercentage;
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number of dozens of toys purchased");
		int toysPurchased = scan.nextInt();
		System.out.println("Enter the price per dozen");
		int pricePerDozen = scan.nextInt();
		System.out.println("Enter the selling price of 1 toy");
		int sellingPrice = scan.nextInt();
		float profitPercentage = calculateProfit(toysPurchased, pricePerDozen, sellingPrice);
		System.out.println("Sam's profit percentage is " + String.format("%.2f", profitPercentage) + " percent");
		scan.close();
	}

}
