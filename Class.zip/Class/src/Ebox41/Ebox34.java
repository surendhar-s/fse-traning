package Ebox41;

import java.util.Scanner;

public class Ebox34 {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		String day[]=new String[7];
		day[0]="Sun";
		day[1]="Mon";
		day[2]="Tue";
		day[3]="Wed";
		day[4]="Thu";
		day[5]="Fri";
		day[6]="Sat";
		System.out.println("Enter the day number");
		int n=scan.nextInt();
		System.out.println("Day of the week is "+day[n-1]);
		scan.close();
	}

}
