package Ebox41;

import java.util.Scanner;

public class Ebox31{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the string ");
		String url=scan.next();
		System.out.println("Enter the start string ");
		String prefix=scan.next();
		boolean bool=url.startsWith(prefix);
		if(bool) {
			System.out.println("\""+url+"\"starts with \""+prefix+"\"" );
		}
		else {
			System.out.println("\""+url+"\"does not starts with \""+prefix+"\"" );
		}
		scan.close();
	}

}
