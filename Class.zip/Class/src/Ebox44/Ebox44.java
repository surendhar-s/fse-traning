package Ebox44;

import java.util.Scanner;

public class Ebox44 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int employeeId;
		String name;
		System.out.println("Enter the number of GenCs");
		int n = scan.nextInt();
		int temp = 0;
		Student student[] = new Student[n];
		while (temp < n) {
			System.out.println("Enter the Employee Id");
			employeeId = scan.nextInt();
			System.out.println("Enter Name");
			name = scan.next();
			student[temp] = new Student();
			student[temp].setEmployeeId(employeeId);
			student[temp].setName(name);
			temp++;
		}
		for (int i = 0; i < n; i++)
			student[i].display();
		scan.close();
	}

}
