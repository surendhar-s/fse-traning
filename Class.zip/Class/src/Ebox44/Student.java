package Ebox44;

public class Student {
	private static final String COHORT_CODE = "CHNAJ19004";
	int employeeId;
	String name;

	public int getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	void display() {
		System.out.println(this.employeeId + " " + this.name + " " + COHORT_CODE);
	}
}
