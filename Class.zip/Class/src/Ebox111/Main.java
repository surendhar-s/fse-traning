package Ebox111;

import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws IOException {
		Scanner scan = new Scanner(System.in);
		String fileName = scan.nextLine();
		FileReader fileReader = new FileReader("C:\\Users\\768712\\Desktop\\" + fileName + ".txt");
		int i;
		String readedString = "";
		while ((i = fileReader.read()) != -1) {
			if (i == 10) {
				System.out.println(readedString);
				readedString = "";
			} else {
				readedString += (char) i;
			}
		}
		scan.close();
		fileReader.close();
	}

}
