package Ebox121;

import java.util.Scanner;

public class Main {
	void calculateProfit(float buyingPrice, float sellingPrice) {
		float profit = buyingPrice - sellingPrice;
		System.out.println("Profit: "+profit);
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		float buyingPrice=scan.nextFloat();
		float sellingPrice=scan.nextFloat();
		Main main=new Main();
		main.calculateProfit(buyingPrice, sellingPrice);
		scan.close();
	}

}
