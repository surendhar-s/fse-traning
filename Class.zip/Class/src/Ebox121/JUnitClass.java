package Ebox121;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class JUnitClass {

	@Test
	void test() {
		fail("Not yet implemented");
	}

	void testCaclculateProfit() {

	}
}
