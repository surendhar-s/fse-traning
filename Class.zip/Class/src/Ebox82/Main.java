package Ebox82;

import java.util.Scanner;

class InvalidAgeException extends Exception {
	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "Exception occured: InvalidAgeException: not valid";
	}

}

public class Main {
	@SuppressWarnings("resource")
	public static void main(String[] args) {
		System.out.println("Enter your age");
		Scanner scan = new Scanner(System.in);
		int age = scan.nextInt();
		try {
			if (age < 19)
				throw new InvalidAgeException();
			System.out.println("Welcome to vote");
		} catch (InvalidAgeException e) {
			System.out.println(e);
		}
		scan.close();
	}

}
