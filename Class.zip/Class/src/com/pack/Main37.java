package com.pack;

public class Main37 {
	@Example(add = "hello")
	void show() {
		System.out.println("Hello world!!!");
	}

	public static void main(String[] args) {
		Main37 main37 = new Main37();
		main37.show();
	}

}