package com.pack;

public class Main18 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			int d, a = 2;
			d = a / 0;
			System.out.println(d);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

}