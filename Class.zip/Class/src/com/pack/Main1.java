package com.pack;

class Box1 {
	double width;
	double height;
	double depth;

	double volume() {
		return width * height * depth;
	}
}

public class Main1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box1 box1 = new Box1();
		box1.depth = 15;
		box1.height = 20;
		box1.width = 10;
		double vol=box1.volume();
		System.out.println("Volume is: "+vol);
	}

}
