package com.pack;

class Box2 {
	double width;
	double height;
	double depth;

	void setDim(double width, double height, double depth) {
		this.width = width;
		this.height = height;
		this.depth = depth;
	}

	double volume() {
		return width * height * depth;
	}
}

public class Main2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box2 box2 = new Box2();
		box2.setDim(10, 20, 30);
		double vol = box2.volume();
		System.out.println("Volume is: " + vol);
	}

}
