package com.pack;

public class Main20 {

	static void procA() {
		try {
			System.out.println("Inside procA");
			throw new RuntimeException();
		} finally {
			System.out.println("ProcA Finally");
		}
	}

	static void procB() {
		try {
			System.out.println("Inside procB");
			return;
		} finally {
			System.out.println("ProcB Finally");
		}
	}

	static void procC() {
		try {
			System.out.println("Inside procC");
		} finally {
			System.out.println("ProcC Finally");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			procA();
		} catch (Exception e) {
			System.out.println("Caught Exception");
		}
		procB();
		procC();
	}

}
