package com.pack;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Main28 {

	public static void main(String[] args) {
		Date date = new Date();
		System.out.println(date);
		@SuppressWarnings("resource")
		Scanner scan=new Scanner(System.in);
		System.out.print("Enter the date(dd/MM/yy): ");
		String givenDate=scan.nextLine();
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yy");
		simpleDateFormat.setLenient(false);
		try {
			Date date2=simpleDateFormat.parse(givenDate);
			System.out.println(date2);
		}
		catch (ParseException e) {
			System.out.println(e);
		}
		simpleDateFormat = new SimpleDateFormat("dd/MM/yy");
		String s2= simpleDateFormat.format(date);
		System.out.println(s2);
	}
	

}
