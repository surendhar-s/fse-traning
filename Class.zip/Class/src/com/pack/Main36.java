package com.pack;

class Callme1 {
	void call(String msg) {
		System.out.print("[" + msg);
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			System.out.println("Interrupted");
		}
		System.out.print("]");
	}
}

class Caller1 implements Runnable {
	String msg;
	Callme1 target;
	Thread t;

	Caller1(Callme1 targ, String s) {
		target = targ;
		msg = s;
		t = new Thread(this);
		t.start();
	}

	@Override
	public void run() {
		synchronized (target){
			target.call(msg);
		}
	}

}

public class Main36 {

	public static void main(String[] args) {
		Callme1 target = new Callme1();
		Caller1 caller = new Caller1(target, "Hello");
		Caller1 caller2 = new Caller1(target, "Synchronized");
		Caller1 caller3 = new Caller1(target, "World");
		try {
			caller.t.join();
			caller2.t.join();
			caller3.t.join();
		} catch (InterruptedException e) {
			System.out.println("Interrupted");
		}
	}

}