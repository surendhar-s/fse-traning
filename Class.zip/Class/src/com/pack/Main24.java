package com.pack;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.TreeSet;

public class Main24 {
	public static void main(String[] args) {
		Set<String> set=new HashSet<>();
		set.add("F");
		set.add("A");
		set.add("B");
		set.add("C");
		set.add("D");
		set.add("E");
		set.add("G");
		System.out.println(set.size());
		System.out.println(set);
		
		LinkedHashSet<String> linkedHashSet = new LinkedHashSet<>();
		linkedHashSet.add("F");
		linkedHashSet.add("A");
		linkedHashSet.add("B");
		linkedHashSet.add("C");
		linkedHashSet.add("D");
		linkedHashSet.add("E");
		linkedHashSet.add("G");
		System.out.println(linkedHashSet.size());
		System.out.println(linkedHashSet);
		
		Set<String> set1=  new TreeSet<>();
		set1.add("F");
		set1.add("A");
		set1.add("B");
		set1.add("C");
		set1.add("D");
		set1.add("E");
		set1.add("G");
		System.out.println(set1.size());
		System.out.println(set1);
	}

}
