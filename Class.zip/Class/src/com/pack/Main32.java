package com.pack;

public class Main32 {

	public static void main(String[] args) {
		StringBuffer stringBuffer = new StringBuffer("Hello");
		System.out.println(stringBuffer.length());
		System.out.println(stringBuffer.charAt(1));
		stringBuffer.setCharAt(1, 'i');
		System.out.println(stringBuffer);
		stringBuffer.setLength(2);
		System.out.println(stringBuffer.length());
		System.out.println(stringBuffer);
		System.out.println(stringBuffer.capacity());
	}

}
