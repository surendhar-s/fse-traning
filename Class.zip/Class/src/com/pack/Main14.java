package com.pack;

class A7 {
	void call() {
		System.out.println("A7 method");
	}
}

class B7 extends A7 {
	void call() {
		System.out.println("B7 method");
	}
}

class C7 extends A7 {
	void call() {
		System.out.println("C7 method");
	}
}

public class Main14 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A7 a = new A7();
		a.call();
		a = new B7();
		a.call();
		a = new C7();
		a.call();
	}

}