package com.pack;

import java.io.FileWriter;
import java.io.IOException;

public class Main31 {

	public static void main(String[] args) throws IOException {
		FileWriter fileWriter = new FileWriter("C:\\Users\\768712\\Desktop\\Notes1.txt", true);
		fileWriter.write("****This Eclipse written line!!!****");
		fileWriter.close();
	}

}
