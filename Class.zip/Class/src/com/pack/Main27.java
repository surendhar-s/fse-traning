package com.pack;

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Main27 {

	public static void main(String[] args) {
		Calendar calendar = Calendar.getInstance();
		System.out.println(calendar.getTime());
		System.out.println(calendar.get(Calendar.YEAR));
		System.out.println(calendar.get(Calendar.MONTH));
		System.out.println(calendar.get(Calendar.DATE));
		calendar.add(Calendar.YEAR, -4);
		System.out.println(calendar.get(Calendar.YEAR));
		calendar.set(Calendar.MONDAY, 7);
		System.out.println(calendar.get(Calendar.MONTH));
		System.out.println(calendar.getMaximum(Calendar.YEAR));
		System.out.println(calendar.getMinimum(Calendar.YEAR));
		System.out.println(calendar.getActualMaximum(Calendar.MONTH));
		System.out.println(calendar.getActualMinimum(Calendar.MONTH));
		System.out.println(calendar.get(Calendar.DAY_OF_YEAR));
		GregorianCalendar gregorianCalendar = new GregorianCalendar();
		System.out.println(gregorianCalendar);
		int year = gregorianCalendar.get(Calendar.YEAR);
		System.out.println(gregorianCalendar.isLeapYear(year));
	}
}
