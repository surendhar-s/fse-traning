package com.pack;

public interface Maths {
	void arithmetic(int a,int b);
	int c=20;
}
