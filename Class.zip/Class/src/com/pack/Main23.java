package com.pack;

import java.util.Enumeration;
import java.util.Vector;

public class Main23 {

	public static void main(String[] args) {
		Vector<Integer> vector = new Vector<>(3, 2);
		System.out.println(vector.size() + " " + vector.capacity());
		vector.add(1);
		vector.add(2);
		vector.add(3);
		vector.add(4);
		System.out.println(vector.size() + " " + vector.capacity());
		vector.add(5);
		vector.add(6);
		System.out.println(vector.size() + " " + vector.capacity());
		System.out.println(vector);
		Enumeration<Integer> enumeration = vector.elements();
		while (enumeration.hasMoreElements()) {
			System.out.println(enumeration.nextElement());
		}
	}
}