package com.pack;

import java.io.FileReader;
import java.io.IOException;

public class Main30 {
	public static void main(String[] args) throws IOException {
		FileReader fileReader=new FileReader("C:\\Users\\768712\\Desktop\\Notes1.txt");
		int i;
		while((i=fileReader.read())!=-1)
			System.out.print((char)i);
		fileReader.close();
	}
}
