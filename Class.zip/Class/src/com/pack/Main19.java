package com.pack;

public class Main19 {
	static void demoproc() {
		try {
			throw new NullPointerException();
		} catch (NullPointerException e) {
			// TODO: handle exception
			System.out.println("Caught: " + e);
			throw e;
		}
	}

	public static void main(String[] args) {
		try {
			demoproc();
		} catch (NullPointerException e) {
			// TODO: handle exception
			System.out.println("Recaught: " + e);
		}
	}
}
