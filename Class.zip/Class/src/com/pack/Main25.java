package com.pack;

public class Main25 {

	public static void main(String[] args) {
		/*
		 * Map<String, Double> hashMap = new HashMap<>();
		 * System.out.println(hashMap.size()); hashMap.put("DD", 23.232);
		 * hashMap.put("ASD FGF", 8523.21); hashMap.put("QWE RTY", 12.023);
		 * hashMap.put("ZXC VBN", 6325.0); hashMap.put("GAH", 85693.21);
		 * hashMap.put("DD", 5236.0); System.out.println(hashMap.size());
		 * System.out.println(hashMap); Set set = hashMap.entrySet(); Iterator iterator
		 * = set.iterator(); while (iterator.hasNext()) { Map.Entry<String, Double> mp =
		 * (Map.Entry) iterator.next(); System.out.println(mp.getKey() + " " +
		 * mp.getValue()); } System.out.println(); set = hashMap.keySet(); iterator =
		 * set.iterator(); while (iterator.hasNext()) { String str = (String)
		 * iterator.next(); System.out.println(str + " " + hashMap.get(str)); }
		 */

		/*
		 * Map<String, Double> hashMap = new LinkedHashMap<>();
		 * System.out.println(hashMap.size()); hashMap.put("DD", 23.232);
		 * hashMap.put("ASD FGF", 8523.21); hashMap.put("QWE RTY", 12.023);
		 * hashMap.put("ZXC VBN", 6325.0); hashMap.put("GAH", 85693.21);
		 * hashMap.put("DD", 5236.0); System.out.println(hashMap.size());
		 * System.out.println(hashMap); Set set = hashMap.entrySet(); Iterator iterator
		 * = set.iterator(); while (iterator.hasNext()) { Map.Entry<String, Double> mp =
		 * (Map.Entry) iterator.next(); System.out.println(mp.getKey() + " " +
		 * mp.getValue()); } System.out.println(); set = hashMap.keySet(); iterator =
		 * set.iterator(); while (iterator.hasNext()) { String str = (String)
		 * iterator.next(); System.out.println(str + " " + hashMap.get(str)); }
		 */

		/*
		 * Map<String, Double> hashMap = new TreeMap<>();
		 * System.out.println(hashMap.size()); hashMap.put("DD", 23.232);
		 * hashMap.put("ASD FGF", 8523.21); hashMap.put("QWE RTY", 12.023);
		 * hashMap.put("ZXC VBN", 6325.0); hashMap.put("GAH", 85693.21);
		 * hashMap.put("DD", 5236.0); System.out.println(hashMap.size());
		 * System.out.println(hashMap); Set set = hashMap.entrySet(); Iterator iterator
		 * = set.iterator(); while (iterator.hasNext()) { Map.Entry<String, Double> mp =
		 * (Map.Entry) iterator.next(); System.out.println(mp.getKey() + " " +
		 * mp.getValue()); } System.out.println(); set = hashMap.keySet(); iterator =
		 * set.iterator(); while (iterator.hasNext()) { String str = (String)
		 * iterator.next(); System.out.println(str + " " + hashMap.get(str)); }
		 */

		/*
		 * Hashtable<String, Double> hashMap = new Hashtable<>();
		 * System.out.println(hashMap.size()); hashMap.put("DD", 23.232);
		 * hashMap.put("ASD FGF", 8523.21); hashMap.put("QWE RTY", 12.023);
		 * hashMap.put("ZXC VBN", 6325.0); hashMap.put("GAH", 85693.21);
		 * hashMap.put("DD", 5236.0); System.out.println(hashMap.size());
		 * System.out.println(hashMap); Set set = hashMap.entrySet(); Iterator iterator
		 * = set.iterator(); while (iterator.hasNext()) { Map.Entry<String, Double> mp =
		 * (Map.Entry) iterator.next(); System.out.println(mp.getKey() + " " +
		 * mp.getValue()); } System.out.println(); set = hashMap.keySet(); iterator =
		 * set.iterator(); while (iterator.hasNext()) { String str = (String)
		 * iterator.next(); System.out.println(str + " " + hashMap.get(str)); }
		 * System.out.println(); Enumeration enumeration = hashMap.keys(); while
		 * (enumeration.hasMoreElements()) { String str = (String)
		 * enumeration.nextElement(); System.out.println(str + " " + hashMap.get(str));
		 * }
		 */

		/*
		 * Properties properties = new Properties();
		 * System.out.println(properties.size()); properties.put("Praveen", "DD");
		 * properties.put("Me", "Suren"); properties.put("Arul", "Abi");
		 * properties.put("Sugu", "Shruthi"); properties.put("KT", "Harshini");
		 * System.out.println(properties); Set set = properties.keySet(); Iterator
		 * iterator = set.iterator(); while (iterator.hasNext()) { String str = (String)
		 * iterator.next(); System.out.println(str + " " + properties.getProperty(str));
		 * }
		 */
	}

}
