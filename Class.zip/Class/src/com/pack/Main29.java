package com.pack;

import java.io.File;

public class Main29 {

	public static void main(String[] args) {
		File file = new File("C:\\Users\\768712\\Desktop\\Notes1.txt");
		System.out.println("Name " + file.getName());
		System.out.println("Path " + file.getPath());
		System.out.println("Absolute Path " + file.getAbsolutePath());
		System.out.println("Parent " + file.getParent());
		System.out.println("isFile " + file.isFile());
		System.out.println("isDirectory " + file.isDirectory());
		System.out.println("length " + file.length());
		System.out.println("lastModified " + file.lastModified());
		System.out.println("canWrite " + file.canWrite());
		System.out.println("canRead " + file.canRead());
		System.out.println("isHidden " + file.isHidden());
	}

}
