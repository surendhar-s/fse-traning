package com.pack;

class A9 implements Maths {

	@Override
	public void arithmetic(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a + b + " " + Maths.c);
	}

}

class B9 implements Maths {
	@Override
	public void arithmetic(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a-b +" "+Maths.c);
	}

	void show() {
		System.out.println("Un-implemented method");
	}
}

public class Main16 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Maths maths = new A9();
		maths.arithmetic(10, 20);
		maths = new B9();
		maths.arithmetic(10, 20);
		((B9) maths).show();
	}

}
