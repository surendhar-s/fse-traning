package com.pack;

import java.util.Date;

public class Main26 {

	public static void main(String[] args) {
		Date date = new Date();
		System.out.println(date);
		Date date2 = new Date(6657354);
		System.out.println(date2);
		System.out.println(date.compareTo(date2));
		System.out.println(date.before(date2));
		System.out.println(date.after(date2));
		System.out.println(date.getTime());
	}

}
