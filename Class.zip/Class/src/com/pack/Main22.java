package com.pack;

import java.util.LinkedList;

public class Main22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LinkedList<Integer> list = new LinkedList<Integer>();
		System.out.println(list.size());
		list.add(10);
		list.add(20);
		list.addFirst(5);
		list.addLast(30);
		list.add(2, 7);
		list.add(98);
		list.add(65);
		System.out.println(list);
		list.remove(2);
		list.removeFirst();
		list.removeLast();
		System.out.println(list);
		System.out.println(list.get(1));
		System.out.println(list.getFirst());
		System.out.println(list.getLast());
	}

}