package com.pack;

class Box {
	double width;
	double height;
	double depth;

}

public class Main {

	public static void main(String[] args) {
		// Scanner scan = new Scanner(System.in);
		Box box = new Box();
		box.depth = 15;
		box.height = 20;
		box.width = 10;
		double vol;
		vol = box.width * box.height * box.depth;
		System.out.println(vol);
	}

}
