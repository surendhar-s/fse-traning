package com.pack;

class A6 {
	void show() {
		System.out.println("Base class method");
	}
}

class B6 extends A6 {
	void show() {
		super.show();
		System.out.println("Derived class method");
	}
}

public class Main13 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B6 b6 = new B6();
		b6.show();
	}

}
