package com.pack;

class Box5 {
	double width;
	double height;
	double depth;

	double volume() {
		return width * height * depth;
	}
}

class BoxWeight extends Box5 {
	double weight;

	public BoxWeight(double w, double d, double h, double m) {
		width = w;
		depth = d;
		height = h;
		weight = m;
	}
}

public class Main9 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BoxWeight boxWeight = new BoxWeight(10, 20, 30, 40);
		double vol = boxWeight.volume();
		System.out.println(vol);
	}

}
