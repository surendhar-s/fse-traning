package com.pack;

interface A10 {
	void add1();
}

interface B10 {
	void add2();
}

interface C10 extends A10, B10 {
	void add3();
}

class D1 implements C10 {
	@Override
	public void add1() {
		// TODO Auto-generated method stub
		System.out.println("Add1");
	}

	@Override
	public void add2() {
		// TODO Auto-generated method stub
		System.out.println("Add2");
	}

	@Override
	public void add3() {
		// TODO Auto-generated method stub
		System.out.println("Add3");
	}
}

public class Main17 {
	@SuppressWarnings("unused")
	public static void main(String[] args) {
		D1 d1 = new D1();
	}
}
