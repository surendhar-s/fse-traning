package com.pack;
class A4{
	A4(int a){
		System.out.println("A4");
	}
}
class B4 extends A4{
	B4(){
		super(1);
		System.out.println("B4");
	}
}
class C4 extends B4{
	C4(){
		System.out.println("C4");
	}
}
public class Main12 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//A4 c4=new C4();
	}

}
