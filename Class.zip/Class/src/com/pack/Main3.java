package com.pack;

class Box3 {
	double width;
	double height;
	double depth;

	public Box3(double width, double height, double depth) {
		this.width = width;
		this.height = height;
		this.depth = depth;
	}

	double volume() {
		return width * height * depth;
	}
}

public class Main3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box3 box3 = new Box3(10, 20, 30);
		double vol = box3.volume();
		System.out.println("Volume is: " + vol);
	}

}
