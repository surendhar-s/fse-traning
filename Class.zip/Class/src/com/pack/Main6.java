package com.pack;

public class Main6 {
	static int a = 4;
	static int b;

	static void meth(int x) {
		System.out.println(x + " " + a + " " + b);
	}

	static {
		System.out.println("Block initialized");
		b = a * 3;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		meth(10);
	}

}
