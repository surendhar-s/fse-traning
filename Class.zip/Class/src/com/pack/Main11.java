package com.pack;

class A3 {
	int i;
}

class B3 extends A3 {
	int i;

	B3(int a, int b) {
		super.i = a;
		i = b;
	}

	void show() {
		System.out.println("i: " + i);
		System.out.println("Super i: " + super.i);
	}
}

public class Main11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B3 b3 = new B3(1, 2);
		b3.show();
	}

}
