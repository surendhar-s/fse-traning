package com.pack;

class Overload {
	void test() {
		System.out.println("No paramenter");
	}

	void test(int a) {
		System.out.println("a=" + a);
	}

	void test(double a, double b) {
		System.out.println("a=" + a + " " + "b=" + b);
	}
}

public class Main5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Overload overload = new Overload();
		overload.test();
		overload.test(10);
		overload.test(20.0, 30.20);
	}

}
