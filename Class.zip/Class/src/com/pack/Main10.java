package com.pack;

class Box6 {
	private double width;
	private double height;
	private double depth;

	double volume() {
		return width * height * depth;
	}

	Box6() {
		width = height = depth = -1;
	}

	Box6(Box6 ob) {
		width = ob.width;
		height = ob.height;
		depth = ob.depth;
	}

	Box6(double len) {
		width = height = depth = len;
	}

	Box6(double w, double h, double d) {
		width = w;
		height = h;
		depth = d;
	}
}

class BoxWeight1 extends Box6 {
	double weight;

	public BoxWeight1() {
		super();
		weight = -1;
	}

	BoxWeight1(BoxWeight1 ob) {
		super(ob);
		weight = ob.weight;
	}

	BoxWeight1(double l, double we) {
		super(1);
		weight = we;
	}

	BoxWeight1(double w, double d, double h, double m) {
		super(w, h, d);
		weight = m;
	}
}

class Shipment extends BoxWeight1 {
	double cost;

	public Shipment(double w, double h, double d, double m, double c) {
		super(w, h, d, m);
		cost = c;
	}
}

public class Main10 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*BoxWeight1 boxWeight11 = new BoxWeight1();
		BoxWeight1 boxWeight12 = new BoxWeight1(1, 2, 3, 4);
		BoxWeight1 boxWeight13 = new BoxWeight1(3, 2);
		BoxWeight1 boxWeight14 = new BoxWeight1(boxWeight11);*/
		Shipment shipment = new Shipment(1, 2, 3, 4, 5);
		double vol;
		vol = shipment.volume();
		System.out.println(vol);
		vol = shipment.volume();
		System.out.println(vol);
		vol = shipment.volume();
		System.out.println(vol);
		vol = shipment.volume();
		System.out.println(vol);
	}

}