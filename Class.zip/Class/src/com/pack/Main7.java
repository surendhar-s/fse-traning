package com.pack;

class A1{
	static int a=10;
	static int b=30;
	static void meth() {
		System.out.println(a);
	}
}
class Main7 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A1.meth();
	}

}
