package Ebox101;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Scanner;

public class FindMaximumRun {

	public static void main(String[] args) {
		HashMap<String, Long> hashMap = new HashMap<String, Long>();
		System.out.println("Enter the number of playes");
		Scanner scan = new Scanner(System.in);
		int n = Integer.parseInt(scan.nextLine());
		for (int i = 0; i < n; i++) {
			System.out.println("Enter the details of the player " + (i + 1));
			String key = scan.nextLine();
			Long value = new Long(Long.parseLong(scan.nextLine()));
			hashMap.put(key, value);
		}
		Long maxRun = Collections.max(hashMap.values());
		for (Entry<String, Long> entry : hashMap.entrySet()) {
			if (entry.getValue() == maxRun)
				System.out.println(entry.getKey());
		}
		scan.close();
	}
}
