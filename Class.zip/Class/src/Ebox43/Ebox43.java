package Ebox43;

import java.util.Scanner;

public class Ebox43 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the product id");
		long id = scan.nextLong();
		System.out.println("Enter the product name");
		String productName = scan.next();
		System.out.println("Enter the supplier name");
		String supplierName = scan.next();
		Product product = new Product(id, productName, supplierName);
		System.out.println("Product Id is " + product.getId());
		System.out.println("Product Name is " + product.getProductName());
		System.out.println("Supplier Name is " + product.getSupplierName());
		scan.close();
	}

}
