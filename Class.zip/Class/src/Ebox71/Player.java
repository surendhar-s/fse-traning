package Ebox71;

public abstract class Player {
	protected String name;
	protected String teamName;
	protected int noOfMatches;

	public Player(String name, String teamName, int noOfMatches) {
		this.name = name;
		this.teamName = teamName;
		this.noOfMatches = noOfMatches;
	}

}
