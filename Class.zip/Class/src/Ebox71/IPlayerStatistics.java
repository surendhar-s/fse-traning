package Ebox71;

public interface IPlayerStatistics {
	public void displayPlayerStatistics();
}
