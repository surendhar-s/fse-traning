package Ebox71;

public class CricketPlayer extends Player implements IPlayerStatistics {
	private int totalRunsScored;
	private int noOfWicketsTaken;

	public CricketPlayer(String name, String teamName, int noOfMatches, int totalRunsScored, int noOfWicketsTaken) {
		super(name, teamName, noOfMatches);
		this.totalRunsScored = totalRunsScored;
		this.noOfWicketsTaken = noOfWicketsTaken;
	}

	@Override
	public void displayPlayerStatistics() {
		System.out.println("Player Details");
		System.out.println("Player name : " + this.name + "\nTeam name : " + this.teamName + "\nNo of matches: "
				+ this.noOfMatches + "\nTotal runsscored : " + this.totalRunsScored + "\nNo of wickets taken : "
				+ this.noOfWicketsTaken);
	}

}
