package Ebox71;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.println("Menu\n1.Cricket Player Details\n2.Hockey Player Details\nEnter choice");
		Scanner scan = new Scanner(System.in);
		int choice=Integer.parseInt(scan.nextLine());
		String name;
		String teamName;
		int noOfWicketsTaken;
		int totalRunsScored;
		int noOfMatches;
		int noOfGoals;
		String position;
		switch (choice) {
		case 1:
			System.out.println("Enter player name");
			name=scan.nextLine();
			System.out.println("Enter the team name");
			teamName=scan.nextLine();
			System.out.println("Enter the number of match played");
			noOfMatches=scan.nextInt();
			System.out.println("Enter totla runs scaored");
			totalRunsScored=scan.nextInt();
			System.out.println("Enter totle number of wickets taken");
			noOfWicketsTaken=scan.nextInt();
			CricketPlayer cricketPlayer=new CricketPlayer(name, teamName, noOfMatches, totalRunsScored, noOfWicketsTaken);
			cricketPlayer.displayPlayerStatistics();
			break;
		case 2:
			System.out.println("Enter player name");
			name=scan.nextLine();
			System.out.println("Enter the team name");
			teamName=scan.nextLine();
			System.out.println("Enter the number of match played");
			noOfMatches=scan.nextInt();
			System.out.println("Enter the position");
			position=scan.nextLine();
			System.out.println("Enter total number of goals taken");
			noOfGoals=scan.nextInt();
			HockeyPlayer hockeyPlayer=new HockeyPlayer(name, teamName, noOfMatches, position, noOfGoals);
			hockeyPlayer.displayPlayerStatistics();
			break;
		default:
			break;
		}
		scan.close();
	}

}
