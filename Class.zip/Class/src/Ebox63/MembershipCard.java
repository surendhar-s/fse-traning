package Ebox63;

public class MembershipCard extends Card {
	private Integer rating;

	public Integer getRating() {
		return rating;
	}

	public void setRating(Integer rating) {
		this.rating = rating;
	}

	public MembershipCard(String holderName, String cardNumber, String expiryDtae, Integer rating) {
		super(holderName, cardNumber, expiryDtae);
		this.rating = rating;
	}
}
