package Ebox63;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Select the card\n1.Payback Card\n2.Membership Card");
		int choice=scan.nextInt();
		String cardDetails;
		switch (choice) {
		case 1:
			System.out.println("Enter the Card Details:");
			cardDetails=scan.next();
			System.out.println("Enter points in card ");
			Integer pointsEarned=new Integer(scan.nextInt());
			System.out.println("Enter Amount ");
			Double totalAmount=new Double(scan.nextDouble());
			String parsedString[]=cardDetails.split("\\|");
			PaybackCard paybackCard=new PaybackCard(parsedString[0], parsedString[1], parsedString[2], pointsEarned, totalAmount);
			System.out.println(paybackCard.getHolderName()+"'s Payback Card Details:\nCard Number "+paybackCard.getCardNumber()+"\nPoints Earned "+paybackCard.getPointsEarned()+"\nTotal Amount "+paybackCard.getTotalAmount());
			break;
		case 2:
			System.out.println("Enter the Card Details:");
			cardDetails=scan.next();
			System.out.println("Enter rating in card ");
			Integer rating=new Integer(scan.nextInt());
			String parsedString1[]=cardDetails.split("\\|");
			for(String str:parsedString1)
				System.out.println(str);
			MembershipCard membershipCard = new MembershipCard(parsedString1[0], parsedString1[1], parsedString1[2], rating);
			System.out.println(membershipCard.getHolderName()+"'s Payback Card Details:\nCard Number "+membershipCard.getCardNumber()+"\nRating "+membershipCard.getRating());
		default:
			break;
		}
		scan.close();
	}

}