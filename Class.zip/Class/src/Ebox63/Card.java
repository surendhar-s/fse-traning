package Ebox63;

public abstract class Card {
	protected String holderName;
	protected String cardNumber;
	protected String expiryDtae;

	public String getHolderName() {
		return holderName;
	}

	public void setHolderName(String holderName) {
		this.holderName = holderName;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getExpiryDtae() {
		return expiryDtae;
	}

	public void setExpiryDtae(String expiryDtae) {
		this.expiryDtae = expiryDtae;
	}

	public Card(String holderName, String cardNumber, String expiryDtae) {
		this.holderName = holderName;
		this.cardNumber = cardNumber;
		this.expiryDtae = expiryDtae;
	}

}
