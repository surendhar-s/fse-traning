package Main92;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ArrayListSort {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		int n=scan.nextInt();
		List<Integer> list =new ArrayList<Integer>();
		for(int i=0;i<n;i++)
			list.add(scan.nextInt());
		Collections.sort(list);
		for(int elements:list)
			System.out.println(elements);
		scan.close();
	}

}
