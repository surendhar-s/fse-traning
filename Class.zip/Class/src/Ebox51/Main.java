package Ebox51;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Account Number ");
		String accountNumber = scan.next();
		System.out.println("Enter the Account Balance ");
		int balance = scan.nextInt();
		Account account=new Account(accountNumber, balance);
		System.out.println("Enter 1 to deposit an amount, 2 to withdraw an amount ");
		int choice=scan.nextInt();
		int transactionAmount;
		switch(choice) {
		case 1:
			System.out.println("Enter the amount to deposit");
			transactionAmount=scan.nextInt();
			account.deposit(transactionAmount);
			System.out.println("Your balance after the transaction is: "+account.getBalance());
			break;
		case 2:
			System.out.println("Enter the amount to withdraw");
			transactionAmount=scan.nextInt();
			account.withdraw(transactionAmount);
			System.out.println("Your balance after the transaction is: "+account.getBalance());
		}
		scan.close();
	}
}
