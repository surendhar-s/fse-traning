package Ebox51;

public class Account {
	private String accountNumber;
	private int balance;

	public Account(String accountNumber, int balance) {
		this.accountNumber = accountNumber;
		this.balance = balance;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}

	public int getBalance() {
		return balance;
	}

	public void deposit(int transactionAmount) {
		this.balance += transactionAmount;
	}

	public void withdraw(int transactionAmount) {
		if (this.getBalance() - transactionAmount <= 0) {
			System.out.println("Insufficient Balance!!");
		} else {
			balance = this.getBalance() - transactionAmount;
		}
	}

}
