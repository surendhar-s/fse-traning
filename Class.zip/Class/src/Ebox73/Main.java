package Ebox73;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the product id");
		Long id = new Long(Long.parseLong(scan.nextLine()));
		System.out.println("Enter the product name");
		String productName = scan.nextLine();
		System.out.println("Enter the supplier name");
		String supplierName = scan.nextLine();
		Product product=new Product();
		product.setId(id);
		product.setProductName(productName);
		product.setsupplierName(supplierName);
		System.out.println(product);
		System.out.println("Invoking getClass() method : "+product.getClass());
		scan.close();
	}

}
