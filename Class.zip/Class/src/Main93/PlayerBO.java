package Main93;

import java.util.ArrayList;

public class PlayerBO {
	void displayAllPlayerDetails(ArrayList<Player> playerList) {
		for (int i = 0; i < playerList.size(); i++)
			System.out.println(playerList.get(i));
	}
}
