package Main93;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number of players");
		int n = Integer.parseInt(scan.nextLine());
		ArrayList<Player> playerList = new ArrayList<Player>();
		for (int i = 0; i < n; i++) {
			System.out.println("Enter the player name");
			String name = scan.nextLine();
			System.out.println("Enter the country");
			String country = scan.nextLine();
			System.out.println("Enter the skill");
			String skill = scan.nextLine();
			playerList.add(new Player(name, country, skill));
		}
		new PlayerBO().displayAllPlayerDetails(playerList);
		scan.close();
	}

}
