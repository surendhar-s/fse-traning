package Ebox113;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class UserMainCode {
	public static void displayDate(String givenDate) throws ParseException {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("MMM dd, yyyy");
		SimpleDateFormat simpleDateFormat2 = new SimpleDateFormat("yyyy-MM-dd");
		Date date = simpleDateFormat.parse(givenDate);
		String result = simpleDateFormat2.format(date);
		System.out.println(result);
	}
}
