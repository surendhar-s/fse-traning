package Ebox52;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.println("1. Rectangle\n\n2. Square \r\n\n3. Circle\n\nArea Calculator --- Choose your shape ");
		Scanner scan = new Scanner(System.in);
		int choice = scan.nextInt();
		switch (choice) {
		case 1:
			System.out.println("Enter length and breadth: ");
			int length = scan.nextInt();
			int breadth = scan.nextInt();
			Shape shape = new Rectangle(length, breadth);
			System.out.println("Area of Rectangle is: " + String.format("%.2f", shape.calculateArea()));
			break;
		case 2:
			System.out.println("Enter side ");
			int side = scan.nextInt();
			Shape shape2 = new Square(side);
			System.out.println("Area of Square is: " + String.format("%.2f", shape2.calculateArea()));
			break;
		case 3:
			System.out.println("Enter radius: ");
			int radius = scan.nextInt();
			Shape shape3 = new Circle(radius);
			System.out.println("Area of Rectangle is: " + String.format("%.2f", shape3.calculateArea()));
			break;
		}
		scan.close();
	}
}
