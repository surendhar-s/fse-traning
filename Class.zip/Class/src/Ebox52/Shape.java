package Ebox52;

class Shape {
	protected String shapeName;

	Double calculateArea() {
		return (double) 0;
	}

	public Shape(String shapeName) {
		this.shapeName = shapeName;
	}
}

class Square extends Shape {
	int side;

	public Square(int side) {
		super("Square");
		this.side = side;
	}

	Double calculateArea() {
		return (double) side * side;
	}
}

class Rectangle extends Shape {
	int length;
	int breadth;

	Double calculateArea() {
		return (double) length * breadth;
	}

	public Rectangle(int length, int breadth) {
		super("Rectangle");
		this.length = length;
		this.breadth = breadth;
	}
}

class Circle extends Shape {
	int radius;

	Double calculateArea() {
		return (double) 3.14159265359 * radius * radius;
	}

	public Circle(int radius) {
		super("Circle");
		this.radius = radius;
	}

}