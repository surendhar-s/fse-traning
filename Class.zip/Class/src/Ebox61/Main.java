package Ebox61;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.println("1. Rectangle\n\n2. Square \r\n\n3. Circle \r\n\n4. Circle\n\nArea Calculator --- Choose your shape ");
		Scanner scan = new Scanner(System.in);
		int choice = scan.nextInt();
		switch (choice) {
		case 1:
			System.out.println("Enter length and breadth: ");
			int length = scan.nextInt();
			int breadth = scan.nextInt();
			Shape shape = new Rectangle(length, breadth);
			System.out.println("Area of Rectangle is: " + String.format("%.2f", shape.calculateArea()));
			break;
		case 2:
			System.out.println("Enter side ");
			int side = scan.nextInt();
			Shape shape2 = new Square(side);
			System.out.println("Area of Square is: " + String.format("%.2f", shape2.calculateArea()));
			break;
		case 3:
			System.out.println("Enter radius: ");
			int radius = scan.nextInt();
			Shape shape3 = new Circle(radius);
			System.out.println("Area of Rectangle is: " + String.format("%.2f", shape3.calculateArea()));
			break;
		case 4:
			System.out.println("Enter side ");
			int side1 = scan.nextInt();
			Shape shape4 = new Hexagon(side1);
			shape4.getClass();
			System.out.println("Area of Square is: " + "0.00");
			break;
		}
		scan.close();
	}
}
