package Ebox102;

import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Main {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number of box");
		int n = scan.nextInt();
		Set<Box> set = new HashSet<Box>();
		for (int i = 0; i < n; i++) {
			System.out.println("Enter length");
			double length = scan.nextDouble();
			System.out.println("Enter width");
			double width = scan.nextDouble();
			System.out.println("Enter height");
			double height = scan.nextDouble();
			Box box = new Box(length, width, height);
			if (set.isEmpty())
				set.add(box);
			else {
				for (Box tempBox : set) {
					if (!tempBox.equals(box)) {
						set.add(box);
					}
				}
			}
		}
		System.out.println("Unique boxes in the Set are ");
		for (Box box : set)
			System.out.println(box);
		scan.close();
	}

}
