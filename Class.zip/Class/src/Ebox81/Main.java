package Ebox81;

import java.util.Scanner;

class DivideByZeroException extends Exception {
	private static final long serialVersionUID = 1L;

	@Override
	public String toString() {
		return "DivideByZeroException caught";
	}

}

public class Main {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the 2 numbers");
		int a = scan.nextInt();
		int b = scan.nextInt();
		try {
			if (b == 0)
				throw new DivideByZeroException();
			int c = a / b;
			System.out.println("The quotient of " + a + " " + b + " = " + c);
		} catch (DivideByZeroException e) {
			System.out.println(e);
		} finally {
			System.out.println("Inside finally block");
		}
	}

}
