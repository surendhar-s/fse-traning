package Ebox42;

import java.util.Scanner;

public class Ebox42 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		Product product = new Product();
		System.out.println("Enter the product id");
		product.setId(scan.nextLong());
		System.out.println("Enter the product name");
		product.setProductName(scan.next());
		System.out.println("Enter the supplier name");
		product.setSupplierName(scan.next());
		System.out.println("Product Id is " + product.getId());
		System.out.println("Product Name is " + product.getProductName());
		System.out.println("Supplier Name is " + product.getSupplierName());
		scan.close();
	}

}
