package Ebox114;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class UserMainCode {
	static void displayDate(String givenDate) throws ParseException {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		Date date = simpleDateFormat.parse(givenDate);
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.MONTH, -20);
		Date date2 = calendar.getTime();
		System.out.println(
				"20 Mmonths before " + simpleDateFormat.format(date) + " will be " + simpleDateFormat.format(date2));
	}
}
