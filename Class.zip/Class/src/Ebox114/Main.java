package Ebox114;

import java.text.ParseException;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws ParseException {
		Scanner scan=new Scanner(System.in);
		String givenDate=scan.nextLine();
		UserMainCode.displayDate(givenDate);
		scan.close();
	}

}
