package Main91;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ScoreCalculation {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<Integer>();
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int totalScore = 0;
		int temp = 0;
		float averageScore = 0.0f;
		for (int i = 0; i < n; i++)
			list.add(scan.nextInt());
		for (int elements : list)
			totalScore += elements;
		for (int i = 0; i < n; i++)
			temp += list.get(i);
		averageScore = temp / (float) n;
		System.out.println(totalScore + "\n" + String.format("%.2f", averageScore));
		scan.close();
	}

}
