package com.smcharts.comparator;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;

import com.smcharts.model.StockPrice;

public class DateComparator implements Comparator<StockPrice> {

	@Override
	public int compare(StockPrice o1, StockPrice o2) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Date date1 = null;
		Date date2 = null;
		try {
			date1 = simpleDateFormat.parse(o1.getDate());
			date2 = simpleDateFormat.parse(o2.getDate());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date1.compareTo(date2);
	}
	
}
