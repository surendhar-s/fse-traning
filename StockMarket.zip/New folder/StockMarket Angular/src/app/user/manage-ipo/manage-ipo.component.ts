import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'manage-ipo',
  templateUrl: './manage-ipo.component.html',
  styleUrls: ['./manage-ipo.component.css'],
})
export class ManageIpoComponent implements OnInit {

  constructor(private titleService: Title) {
    titleService.setTitle("Manage IPOs");}

  ngOnInit() {
  }

}
