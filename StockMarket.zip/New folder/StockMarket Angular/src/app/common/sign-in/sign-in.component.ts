import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from 'src/app/service/user.service';
import { User } from 'src/app/models/user';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'sign-in',
  templateUrl: './sign-in.component.html',
  styleUrls: ['./sign-in.component.css']
})
export class SignInComponent implements OnInit {

  users: User;
  invalidLogin: boolean;
  username: string;
  password: string;
  rForm: FormGroup;

  constructor(private router: Router, private loginService: UserService, private fb: FormBuilder, private titleService: Title) {
    titleService.setTitle("Sign in");
    this.onFormSubmit();
  }

  ngOnInit() {
    localStorage.removeItem("userName");
    localStorage.removeItem("userId");
    localStorage.removeItem("userEmail");
    localStorage.removeItem("mobile");

   }

  onSubmit() {

    console.log("On Submit function")
    this.loginService.checkLogin(this.username, this.password).subscribe((result) => {
      this.users = result;
      if (this.users.userType.toString() === "ADMIN")
        this.router.navigate(['admin'])
      else if (this.users.userType.toString() === "USER")
        this.router.navigate(['user'])
      this.invalidLogin = false
      localStorage.setItem("userId",
        this.users.id.toString());
      localStorage.setItem("userEmail",
        this.users.email.toString());
      localStorage.setItem("userName",
        this.users.username.toString());
        if(this.users.mobile!=null)
      localStorage.setItem("mobile",
        this.users.mobile.toString());
    },
      (error) => {
        console.log("err");
        this.invalidLogin = true
      });
  }

  onFormSubmit() {
    this.rForm = this.fb.group({
      'username': [this.username, Validators.required],
      'password': [this.password, Validators.required]
    })
  }
}