import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StockPriceService } from 'src/app/service/stock-price.service';


@Component({
  selector: 'app-stockprices',
  templateUrl: './stockprices.component.html',
  styleUrls: ['./stockprices.component.css']
})
export class StockpricesComponent implements OnInit {
  x:number;
  stockPrices;
  constructor(private router:Router,private stockService:StockPriceService) { }

  ngOnInit() {
    this.x=1;
    this.stockService.getStockPrices().subscribe(async res=>{
      this.stockPrices= await res;
    },err=>{
      console.log(err);
      this.router.navigate(['admin']);
    })
  }

}
