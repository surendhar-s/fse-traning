import { Component, OnInit } from '@angular/core';
import { Company } from 'src/app/models/company';
import { CompanyService } from 'src/app/service/company.service';
import { Router } from '@angular/router';
import { async } from 'q';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-list-company-search',
  templateUrl: './list-company-search.component.html',
  styleUrls: ['./list-company-search.component.css']
})
export class ListCompanySearchComponent implements OnInit {
  value: String;
  userId: number;
  companies;
  valid: Boolean;

  constructor(private router: Router, private companyService: CompanyService, private titleService: Title) {
    titleService.setTitle("Serch companies"); }

  ngOnInit() {  }


  getCompany(event) {
    if ((event.keyCode >= 65 && event.keyCode <= 90) || (event.keyCode >= 48 && event.keyCode <= 57) || (event.keyCode >= 96 && event.keyCode <= 105))
      this.companyService.getCompanyByValue(this.value).subscribe(async res => {
        this.companies = await res;
        this.valid = false;
      }, err => {
        this.valid = true;
        console.log("error");
      });

  }

}
