package com.smcharts.comparator;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

import com.smcharts.model.StockPrice;

public class StockPriceComparator implements Comparator<StockPrice> {

	private List<Comparator<StockPrice>> list;

	@SafeVarargs
	public StockPriceComparator(Comparator<StockPrice>... comparators) {
		this.list = Arrays.asList(comparators);
	}

	@Override
	public int compare(StockPrice o1, StockPrice o2) {
		for (Comparator<StockPrice> comparator : list) {
			int result = comparator.compare(o1, o2);
			if (result != 0)
				return result;
		}
		return 0;
	}

}
