package com.smcharts.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.smcharts.model.Company;

public interface CompanyRepo extends CrudRepository<Company, Long> {

	public List<Company> findBySector(String sectoName);

	@Query(value = "select c from Company c where c.companyName like %?1%")
	public List<Company> getCompanyByValue(String value);

}
