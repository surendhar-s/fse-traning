package com.smcharts.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.smcharts.model.StockPrice;

public interface StockPriceRepo extends CrudRepository<StockPrice, Long> {

	public List<StockPrice> getByCompanyId(long companyId);

	@Query(value = "Select s from StockPrice s where s.companyId in (Select c.id from Company c where c.sector like ?1)")
	public List<StockPrice> getBySector(String sector);

}
