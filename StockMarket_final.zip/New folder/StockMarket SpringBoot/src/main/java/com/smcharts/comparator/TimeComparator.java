package com.smcharts.comparator;

import java.text.SimpleDateFormat;
import java.util.Comparator;
import java.util.Date;

import com.smcharts.model.StockPrice;

public class TimeComparator implements Comparator<StockPrice> {

	@Override
	public int compare(StockPrice o1, StockPrice o2) {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm:ss");
		Date date1 = null;
		Date date2 = null;
		try {
			date1 = simpleDateFormat.parse(o1.getTime());
			date2 = simpleDateFormat.parse(o2.getTime());
		} catch (Exception e) {
			e.printStackTrace();
		}
		long diff = date1.getTime() - date2.getTime();
		return (int) diff;
	}

}
