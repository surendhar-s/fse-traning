package com.smcharts.repo;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.smcharts.model.User;

public interface UserRepo extends CrudRepository<User, Long> {

	@Query("Select u from User u where u.username like ?1 and u.password like ?2")
	public User checkLogin(String username, String password);

	@Query("Select u from User u where u.username like ?1")
	public User checkUserName(String username);
}
